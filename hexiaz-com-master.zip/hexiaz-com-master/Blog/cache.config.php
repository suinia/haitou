<?php

return array(
    'default' => array(
        'type' => 'file',
        'path' => Hx::$path . 'Runtime/Cache/',
        'compress' => false,
        'gc' => false
    )
);
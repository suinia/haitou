<?php

return array(
    'default' => array(
        'file' => dirname(Hx::$path) . '/database.db',
        'driver' => 'pdo',
        'type' => 'sqlite'
    )
);